import React from 'react';
import {FireContainer, FireContainerDeactivate} from "./styles/FireStyles";
import {connect} from "react-redux";
import {OverlayTrigger, Tooltip} from "react-bootstrap";

const Fire = ({mainText, secondaryText, color, isAnimation}) => {

    const tooltipContent = `
    Animation: ${isAnimation},
    Color: ${color},
    Main text: ${mainText},
    Secondary text: ${secondaryText}
    `;

    const renderTooltip = (props) => (
        <Tooltip id="animation-tooltip" {...props}>
            {tooltipContent}
        </Tooltip>
    );

    return (
        <>
            <OverlayTrigger
                placement="top"
                delay={{show: 250, hide: 400}}
                overlay={renderTooltip}
            >
                <div> {isAnimation ?
                    <FireContainer color={color ? color : "cyan"}>
                        <div className="containerAnimation">
                            <div className="containerText">
                                <div className="mainText">{mainText}</div>
                                <div className="secondaryText">{secondaryText}</div>
                            </div>
                        </div>
                    </FireContainer>
                    :
                    <FireContainerDeactivate color={color ? color : "cyan"}>
                        <div className="containerAnimation">
                            <div className="containerText">
                                <div className="mainText">{mainText}</div>
                                <div className="secondaryText">{secondaryText}</div>
                            </div>
                        </div>
                    </FireContainerDeactivate>}
                </div>
            </OverlayTrigger>
        </>
    );
}

const mapStateToProps = state => ({
    mainText: state.mainText,
    secondaryText: state.secondaryText,
    counter: state.counter,
    color: state.color,
    isAnimation: state.isAnimation
})

export default connect(mapStateToProps)(Fire);